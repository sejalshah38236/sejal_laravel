<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\users;
use Hash;

class usersController extends Controller
{
    //
    public function index()
        {
           $users = users::all();
           if($users->count() > 0){
           
         
           return response()->json([
            'users' => 200,
            'users' => $users
           ], 200);

        }
        else
        {
            return response()->json([
                'status' => 404,
                'message' => 'No Records Found'
               ], 404);
        }
           
        }
        public function store(Request $request)
    {

		$validate=Validator::make($request->all(),[
            'name'=>'Required|string|max:191',
            'email'=>'Required|email|max:191',
            'password'=>'Required'
			
        ]);
		
		if($validate->fails())
		{
			return response()->json([
				'status' => 422, 
				'errors' => $validate->messages()
            ], 422);
		}
		else
		{
			$data=new users;
			$data->name=$request->name;
			$data->email=$request->email;
            $data->password=$request->password;
			
			$data->save();
			return response()->json([
			'status'=>200,
			
			'message' => "user Register Successfully"
			],200);
           
			
    }
}

public function login(Request $request)
	{
		$validate=Validator::make($request->all(),[
            'email'=>'Required|email',
            'password'=>'Required'
        ]);
		
		if($validate->fails())
		{
			return [
				'status' => 200, 
				'message' => $validate->messages(),
			];
		}
		else
		{
			$users=users::where('email' , '=' , $request->email)->first();	
			if(! $users ||  Hash::check($request->password,$users->password))
			{
				return response()->json([
					'status'=>200,
					'message'=>"user Login Failed "
					]);
			}
			else
			{
					return response()->json([
					'status'=>200,
					'message'=>"User Login Successfully",
					
					]);
				
			
				
				}	
            }
        }

     
        public function upload(Request $request)
        {
    
            $validate=Validator::make($request->all(),[
                'name'=>'Required',
                'file'=>'Required'
            ]);
            
            if($validate->fails())
            {
                return [
                    'success' => 200, 
                    'message' => $validate->messages(),
                ];
            }
            else
            {
                $data=new user;
                $data->name=$request->name;
        
                if($request->hasFile('file'))
                {
                    $file=$request->file('file');		
                    $filename=time().'_img.'.$request->file('file')->getClientOriginalExtension();
                    $file->move('upload/customer/',$filename);  // use move for move image in public/images
                    $data->file=$filename;
                }
                $data->save();
                return response()->json([
                'status'=>200,
                
                'message'=>"Register Success"
                ]);
              
            }
        }
    
    }
