<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class uploadController extends Controller
{
    //
    public function upload(Request $request)
    {

        $validate=Validator::make($request->all(),[
            'name'=>'Required',
            'file'=>'Required'
        ]);
        
        if($validate->fails())
        {
            return [
                'success' => 0, 
                'message' => $validate->messages(),
            ];
        }
        else
        {
            $data=new user;
            $data->name=$request->name;
    
            if($request->hasFile('file'))
            {
                $file=$request->file('file');		
                $filename=time().'_img.'.$request->file('file')->getClientOriginalExtension();
                $file->move('upload/customer/',$filename);  // use move for move image in public/images
                $data->file=$filename;
            }
            $data->save();
            return response()->json([
            'status'=>200,
            
            'message'=>"Register Success"
            ]);
          
        }
    }
}
